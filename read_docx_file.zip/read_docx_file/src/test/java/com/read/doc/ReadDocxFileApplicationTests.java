package com.read.doc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadDocxFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
