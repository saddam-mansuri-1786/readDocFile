package com.read.doc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadDocxFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadDocxFileApplication.class, args);
	}

}
